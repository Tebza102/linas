# Lina Client Inputs Register

| ID | Input | Purpose | Current source/status | Owner | Needed by | Build treatment |
|---|---|---|---|---|---|---|
| I-001 | Existing logo files | Brand application and interface | Client has logo; file not yet added here | Tebogo/client | 28 Jul | Use supplied file once uploaded |
| I-002 | Menu and prices | Menu page, ordering and menu asset | To be attached | Tebogo/client | 28 Jul | Structured placeholder until received |
| I-003 | Instagram handle/content | Interim gallery and visual direction | Account exists; details not yet recorded | Tebogo/client | 28 Jul | Use only approved/publicly supplied media |
| I-004 | Original food/event photography | Final website and campaigns | Client will produce | Client | Post-Phase 1 acceptable | Use labelled interim imagery; replace later |
| I-005 | Business legal/trading information | Profile, footer and formal stationery | Not yet supplied | Client | 30 Jul | Do not invent; placeholder/omit as appropriate |
| I-006 | Contact details and WhatsApp | Conversion actions | Not yet confirmed in this pack | Client | 28 Jul | Keep configurable placeholder |
| I-007 | Operating hours | Ordering/contact expectations | Not yet confirmed | Client | 29 Jul | Label as pending |
| I-008 | Delivery/service area | Ordering qualification | Not yet confirmed | Client | 29 Jul | Do not promise unsupported areas |
| I-009 | Catering package details | Catering conversion | Not yet confirmed | Client | 29 Jul | Use enquiry-led structure rather than invented packages |
| I-010 | Testimonials/reviews | Trust proof | Not supplied | Client | Phase 2 or before launch | Omit rather than fabricate |
| I-011 | GEP scope/reporting requirements | Compliance and reporting | Existing project context; source document to be added if available | Tebogo | 29 Jul | Use current known requirements, flag assumptions |

## Status values
Not requested / Requested / Received / Approved / Rejected / Replaced
