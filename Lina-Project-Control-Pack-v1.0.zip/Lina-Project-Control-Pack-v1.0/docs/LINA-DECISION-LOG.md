# Lina Decision Log
Use one entry for every decision that changes scope, design, architecture, content treatment or delivery date.

| ID | Date | Decision | Reason | Impact | Approved by | Status |
|---|---|---|---|---|---|---|
| D-001 | 2026-07-28 | Use one Master Product & Delivery Brief as source of truth | Prevent lost decisions and inconsistent work across ChatGPT and Claude | Creates controlled delivery workflow | Tebogo | Approved |
| D-002 | 2026-07-28 | Produce three directions, not three full products | Gives the client meaningful choice without wasting build capacity | Protects Friday deadline | Tebogo | Approved |
| D-003 | 2026-07-28 | Store all brand sources, exports and mock-ups inside the project asset folders | Prevents scattered assets and supports reuse/handover | Requires consistent naming and asset register updates | Tebogo | Approved |
| D-004 | 2026-07-28 | Missing client content will use labelled placeholders and remain in the inputs register | Prevents content gaps from stopping production | Final replacement remains outstanding | Tebogo | Approved |

## New entry template
| D-___ | YYYY-MM-DD | [decision] | [reason] | [scope/time/technical impact] | [name] | Proposed/Approved/Reversed |
