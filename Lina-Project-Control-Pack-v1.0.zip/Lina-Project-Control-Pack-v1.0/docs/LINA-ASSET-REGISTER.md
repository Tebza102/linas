# Lina Asset Register and Folder Rules

## Folder structure
```text
assets/
  source/      Original client-supplied logo, documents, screenshots and reference media
  brand/       Approved logo variants, palette, typography and brand application sheet
  menu/        Menu source, editable design and approved exports
  social/      Post, story, WhatsApp and campaign templates
  mockups/     Uniform, signage, mobile-kitchen, stationery and device mock-ups
```

## Naming convention
`lina-[asset]-[variant]-v[number]-YYYYMMDD.ext`

Examples:
- `lina-logo-primary-v1-20260728.svg`
- `lina-menu-a4-v1-20260730.pdf`
- `lina-uniform-apron-mockup-v1-20260730.png`
- `lina-instagram-story-special-v1-20260730.png`

## Asset rules
- Never overwrite an approved source file; create a new version.
- Keep editable/source and export files together or clearly cross-referenced.
- Record origin and approval status.
- Instagram media is interim reference/content only when usage is authorised.
- Do not treat low-resolution social images as final print assets.

## Register
| Asset | Source/owner | Format | Status | Approved by | Notes |
|---|---|---|---|---|---|
| Existing logo | Client | Pending | Awaiting upload | — | Store original before editing |
| Menu | Client | Pending | Awaiting upload | — | Preserve all supplied pricing/content |
| Instagram media | Client account | Pending | Awaiting account/screenshots | — | Confirm usage and image quality |
