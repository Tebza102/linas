# Lina Project Plan
**Sprint:** 28–31 July 2026  
**Status:** Active

## Milestone 1 — Control pack and asset intake
**Target:** 28 July
- Place this document pack in ChatGPT project files and the Claude repository.
- Add logo, menu and Instagram source material to `/assets/source`.
- Audit repository and confirm stack, data layer and deployment.
- Confirm Phase 1 scope and primary customer journeys.

**Done when:** Claude has read the pack, the source assets are organised and risks are recorded.

## Milestone 2 — Three product/design directions
**Target:** Before client discussion on 29 July
- Produce Premium Catering direction.
- Produce Mobile Kitchen & Ordering direction.
- Produce Integrated Growth Platform direction.
- Include desktop/mobile key views and rationale.
- Prepare a concise client presentation.

**Done when:** Three distinct, credible choices are reviewable without building three separate products.

## Milestone 3 — Direction approval and scope freeze
**Target:** 29 July after client feedback
- Record selected direction.
- Confirm retained elements from other directions.
- Freeze Phase 1 scope.
- Place all extras into Phase 2 or reject them.
- Update Decision Log.

**Done when:** Claude has one unambiguous direction and one frozen feature list.

## Milestone 4 — Brand application and sales assets
**Target:** 29–30 July
- Brand application sheet.
- Menu design/template.
- Digital flyer.
- Business card/contact card.
- Social post/story templates.
- Uniform, signage and mobile-kitchen mock-ups where source material permits.
- Website/device presentation mock-ups.

**Done when:** Approved exports are stored in `/assets`, named consistently and ready for client presentation/use.

## Milestone 5 — Functional Phase 1 build
**Target:** 30 July
- Complete public pages and core journeys.
- Implement lead/order persistence.
- Implement admin inbox, statuses and notes.
- Implement basic analytics dashboard.
- Complete privacy, validation and failure states.

**Done when:** Customer-to-admin flow works end-to-end with stored data.

## Milestone 6 — QA, release and handover
**Target:** 31 July
- Run full checklist.
- Resolve critical defects.
- Produce private/final deployment.
- Update project documents.
- Record Phase 2 backlog and client-input gaps.
- Prepare training/support handover.

**Done when:** Build passes quality gates and the client can review a stable release.

## Daily status template
**Date:**  
**Completed:**  
**Current status:**  
**Risks/blockers:**  
**Client inputs needed:**  
**Decisions made:**  
**Next action:**  
**Reusable components created:**
