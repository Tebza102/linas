# Lina Project Control Pack v1.0

This pack is the temporary production-control system for the 28–31 July 2026 sprint.

## Start here
1. Add this pack to the Lina ChatGPT project.
2. Copy the complete folder contents into the Claude Code repository root.
3. Add the logo, menu and approved Instagram/source media to `assets/source/`.
4. Tell Claude Code: `Read CLAUDE.md and all referenced Lina project documents. Audit the repository first. Do not implement until you have returned the audit and confirmed the Phase 1 direction and scope.`
5. Keep the Decision Log, Client Inputs Register and Project Plan updated.
